package com.talhanation.smallships.world.entity.ship;

import com.talhanation.smallships.config.SmallShipsConfig;
import com.talhanation.smallships.world.entity.ModEntityTypes;
import com.talhanation.smallships.world.entity.ship.abilities.*;
import com.talhanation.smallships.world.entity.ship.hitbox.ShipPartEntity;
import com.talhanation.smallships.world.entity.ship.seat.ShipSeat;
import com.talhanation.smallships.world.item.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class GalleonEntity extends ContainerShip implements Bannerable, Sailable, Cannonable, Seatable, Ability {
    public static final String ID = "galleon";

    /** The biggest hull of the fleet, four sails and the most plating of all - nothing here is cheap. */
    private static final Map<ShipUpgrade, Integer> UPGRADE_COSTS = Map.of(
            ShipUpgrade.IRON_SCANTLINGS, 16,
            ShipUpgrade.COTTON_SAILS, 8,
            ShipUpgrade.COPPER_PLATING, 12
    );
    private static final int ORIGINAL_CONTAINER_SIZE = SmallShipsConfig.Server.shipContainerGalleonContainerSize.get();

    private static final List<ShipPartEntity.Definition> PARTS = List.of(
            ShipPartEntity.Definition.hull(1.75F, -1.5F, 0.0F, 5.0F, 4.0F),//middle1
            ShipPartEntity.Definition.hull(-1.75F, -1.5F, 0.0F, 5.0F, 4.0F),//middle2
            ShipPartEntity.Definition.hull(0.0F, -1.5F, 0.0F, 5.0F, 4.0F),//middle2

            ShipPartEntity.Definition.hull(-4.5F, -1.5F, 1.0F, 2.5F, 4.5F),//back parts
            ShipPartEntity.Definition.hull(-4.5F, -1.5F, -1.0F, 2.5F, 4.5F),//back parts

            ShipPartEntity.Definition.hull(4.8F, -1.5F, 1.0F, 2.5F, 4.5F),//front parts
            ShipPartEntity.Definition.hull(4.8F, -1.5F, -1.0F, 2.5F, 4.5F),//front parts

            ShipPartEntity.Definition.hull(6.5F, 0.0F, 0.0F, 1.0F, 3.0F),//front small

            ShipPartEntity.Definition.mast(4.2F, 0.0F, 0.30F, 12.8F),//front mast
            ShipPartEntity.Definition.mast(-0.2F, 0.0F, 0.30F, 15.25F), //middle mast
            ShipPartEntity.Definition.mast(-4.6F, 0.0F, 0.30F, 11.0F)//back mast
    );

    @Override
    public List<ShipPartEntity.Definition> getParts() {
        return PARTS;
    }
    private static final float seatHeight = 1.35F;
    float x = -1.9F;
    private static final List<ShipSeat> SEATS = List.of(
            ShipSeat.driver(0, -4.75F, seatHeight + 0.4F,1.0F),
            ShipSeat.passenger(1, -4.0F,seatHeight + 0.4F, 0.0F),
            ShipSeat.passenger(2, -4.75F,seatHeight + 0.4F, -1.0F),

            ShipSeat.passenger(3, -3.0F, seatHeight, 1.5F),
            ShipSeat.passenger(4, -3.0F, seatHeight, 0.5F),
            ShipSeat.passenger(5, -3.0F, seatHeight, -0.5F),
            ShipSeat.passenger(6, -3.0F, seatHeight,-1.5F),

            ShipSeat.passenger(7, -2.0F, seatHeight, 1.5F),
            ShipSeat.passenger(8, -2.0F, seatHeight, 0.5F),
            ShipSeat.passenger(9, -2.0F, seatHeight, -0.5F),
            ShipSeat.passenger(10, -2.0F, seatHeight,-1.5F),

            ShipSeat.cannon(11, -1.0F, seatHeight,1.5F, 0),
            ShipSeat.gunner(12, -1.0F,seatHeight, 0.5F, 0),
            ShipSeat.gunner(13, -1.0F, seatHeight,-0.5F, 1),
            ShipSeat.cannon(14, -1.0F, seatHeight,-1.5F, 1),

            ShipSeat.passenger(15, 0.0F, seatHeight, 1.5F),
            ShipSeat.passenger(16, 0.0F, seatHeight, 0.5F),
            ShipSeat.passenger(17, 0.0F, seatHeight, -0.5F),
            ShipSeat.passenger(18, 0.0F, seatHeight,-1.5F),

            ShipSeat.cannon(19, 1.0F, seatHeight,1.5F, 2),
            ShipSeat.gunner(20, 1.0F, seatHeight, 0.5F, 2),
            ShipSeat.gunner(21, 1.0F, seatHeight,-0.5F, 3),
            ShipSeat.cannon(22, 1.0F, seatHeight,-1.5F, 3),

            ShipSeat.passenger(23, 2.0F, seatHeight, 1.5F),
            ShipSeat.passenger(24, 2.0F, seatHeight, 0.5F),
            ShipSeat.passenger(25, 2.0F, seatHeight, -0.5F),
            ShipSeat.passenger(26, 2.0F, seatHeight,-1.5F),

            ShipSeat.passenger(27, 3.0F, seatHeight, 1.5F),
            ShipSeat.passenger(28, 3.0F, seatHeight, 0.5F),
            ShipSeat.passenger(29, 3.0F, seatHeight, -0.5F),
            ShipSeat.passenger(30, 3.0F, seatHeight,-1.5F),

            ShipSeat.passenger(31, 4.0F, seatHeight + 0.4F,1.0F),
            ShipSeat.passenger(32, 4.75F,seatHeight + 0.4F, 0.0F),
            ShipSeat.passenger(33, 4.0F,seatHeight + 0.4F, -1.0F)
    );


    @Override
    public List<ShipSeat> getSeats() {
        return SEATS;
    }
    public GalleonEntity(EntityType<? extends Boat> entityType, Level level) {
        super(entityType, level, ORIGINAL_CONTAINER_SIZE);
    }

    private GalleonEntity(Level level, double d, double e, double f) {
        this(ModEntityTypes.GALLEON, level);
        this.setPos(d, e, f);
        this.xo = d;
        this.yo = e;
        this.zo = f;
    }

    @Override
    public boolean isEffectedByCannonPenalty() {
        return false;
    }

    public static GalleonEntity summon(Level level, double d, double e, double f) {
        return new GalleonEntity(level, d, e, f);
    }

    @Override
    public Map<ShipUpgrade, Integer> getUpgradeCosts() {
        return UPGRADE_COSTS;
    }

    @Override
    public SmallShipsConfig.ShipAttributes getConfiguredAttributes() {
        return SmallShipsConfig.Server.galleonAttributes;
    }

    @Override
    public int getMaxPassengers() {
        return this.getSeats().size();
    }

    @Override
    public @NotNull Item getDropItem() {
        if (!SmallShipsConfig.Server.shipGeneralDoItemDrop.get()) return ItemStack.EMPTY.getItem();
        return ModItems.GALLEON_ITEMS.get(this.getVariant());
    }

    @Override
    public BiomeModifierType getBiomeModifierType() {
        return SmallShipsConfig.Server.shipModifierGalleonBiome.get();
    }

    @Override
    public void waterSplash(){
        Vec3 vector3d = this.getViewVector(0.0F);
        float f0 = Mth.cos(this.getYRot() * ((float)Math.PI / 180F)) * 1.2F;
        float f1 = Mth.sin(this.getYRot() * ((float)Math.PI / 180F)) * 1.2F;
        float f2 =  4F - this.random.nextFloat() * 0.7F; // höhe
        float f2_ =  -2.3F - this.random.nextFloat() * 0.7F;
        float x = 0; //verschiebung nach rechts/links
        for (int i = 0; i < 2; ++i) {                                                                                                                             //höhe
            this.level().addParticle(ParticleTypes.DOLPHIN, this.getX() - vector3d.x * (double) f2 + (double) f0, this.getY() - vector3d.y + 0.5D, this.getZ() - vector3d.z * (double) f2 + (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.DOLPHIN, this.getX() - vector3d.x * (double) f2 - (double) f0, this.getY() - vector3d.y + 0.5D, this.getZ() - vector3d.z * (double) f2 - (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.DOLPHIN, this.getX() - vector3d.x * (double) f2 + (double) f0, this.getY() - vector3d.y + 0.5D, this.getZ() - vector3d.z * (double) f2 + (double) f1 * 5.1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.DOLPHIN, this.getX() - vector3d.x * (double) f2 - (double) f0, this.getY() - vector3d.y + 0.5D, this.getZ() - vector3d.z * (double) f2 - (double) f1 * 5.1, 0.0D, 0.0D, 0.0D);

            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2 + (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) f2 + (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2 - (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) f2 - (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2 + (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) f2 + (double) f1 * 1.1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2 - (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) f2 - (double) f1 * 1.1, 0.0D, 0.0D, 0.0D);

            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2_ + (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) + (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2_ - (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) - (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2_ + (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) + (double) f1 * 1.1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.SPLASH, this.getX() - vector3d.x * (double) f2_ - (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) - (double) f1 * 1.1, 0.0D, 0.0D, 0.0D);

            this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - vector3d.x * (double) f2_ + (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) + (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - vector3d.x * (double) f2_ - (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) - (double) f1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - vector3d.x * (double) f2_ + (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) + (double) f1 * 1.1, 0.0D, 0.0D, 0.0D);
            this.level().addParticle(ParticleTypes.BUBBLE, this.getX() - vector3d.x * (double) f2_ - (double) f0, this.getY() - vector3d.y + 0.8D, this.getZ() - vector3d.z * (double) (f2_ - x) - (double) f1 * 1.1, 0.0D, 0.0D, 0.0D);
        }
    }

    /**
     *  Cannon Positioning:
     *  offset X: Defines the X offset -> positive will increase a placement in ships backward
     *  offset Y: Defines the Y offset -> positive will increase a placement in height
     *  offset X: Defines the Z offset -> positive will increase a placement in ships left if its right-sided it will auto negate
     **/
    public CannonPosition getCannonPosition(int index){
        List<CannonPosition> positionList = new ArrayList<>();
        CannonPosition pos1 = new CannonPosition(0.7, 1.0, 1.5, true);
        CannonPosition pos2 = new CannonPosition(0.7, 1.0, 1.5, false);

        CannonPosition pos3 = new CannonPosition(-1.05, 1.0, 1.5, true);
        CannonPosition pos4 = new CannonPosition(-1.05, 1.0, 1.5, false);

        CannonPosition pos5 = new CannonPosition(1.6, 0.1, 1.2, true);
        CannonPosition pos6 = new CannonPosition(1.6, 0.1, 1.2, false);

        CannonPosition pos7 = new CannonPosition(-0.2, 0.1, 1.5, true);
        CannonPosition pos8 = new CannonPosition(-0.2, 0.1, 1.5, false);

        CannonPosition pos9 = new CannonPosition(-1.9F, 0.1, 1.2, true);
        CannonPosition pos10 = new CannonPosition(-1.9F, 0.1, 1.2, false);

        positionList.add(pos1);
        positionList.add(pos2);
        positionList.add(pos3);
        positionList.add(pos4);
        positionList.add(pos5);
        positionList.add(pos6);
        positionList.add(pos7);
        positionList.add(pos8);
        positionList.add(pos9);
        positionList.add(pos10);

        return positionList.get(index);
    }

    public double getCannonAimY(){
        return 4.5D;
    }

    @Override
    public byte getMaxCannonPerSide(){
        return 5;
    }

    /* ---------------- wind profile ---------------- */

    /**
     * Two masts with a mixed rig, historically described as both fast and
     * handy. Flattest profile in the mod: never strong, never weak - that is
     * the all rounder identity and keeps it from dominating through wind too.
     * The three zone multipliers always sum to 3.0.
     */
    @Override
    public float getHeadWindMultiplier() {
        return 0.00F;
    }

    @Override
    public float getSideWindMultiplier() {
        return 0.80F;
    }

    @Override
    public float getTailWindMultiplier() {
        return 1.50F;
    }
}