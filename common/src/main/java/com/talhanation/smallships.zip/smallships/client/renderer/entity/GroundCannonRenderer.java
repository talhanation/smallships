package com.talhanation.smallships.client.renderer.entity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.talhanation.smallships.SmallShipsMod;
import com.talhanation.smallships.client.model.CannonModel;
import com.talhanation.smallships.client.cannon.CannonTrajectory;
import com.talhanation.smallships.world.entity.cannon.Cannon;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import com.talhanation.smallships.world.entity.cannon.GroundCannonEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.NotNull;

public class GroundCannonRenderer extends EntityRenderer<GroundCannonEntity> {
    public GroundCannonRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.shadowRadius = 0.8F;
    }

    @Override
    public @NotNull ResourceLocation getTextureLocation(GroundCannonEntity entity) {
        return ResourceLocation.fromNamespaceAndPath(SmallShipsMod.MOD_ID, "textures/entity/cannon/ship_cannon.png");
    }

    @Override
    public void render(GroundCannonEntity entity, float entityYaw, float partialTicks, @NotNull PoseStack poseStack, @NotNull MultiBufferSource multiBufferSource, int packedLight) {
        ResourceLocation resourceLocation = this.getTextureLocation(entity);
        poseStack.pushPose();
        poseStack.scale(-1.3F, -1.3F, 1.3F);

        /* use the cannon to render as it stores orientation and uses that to shoot */
        Cannon cannon = entity.getCannon();
        float lerpYaw = -(cannon.getPrevYaw() + (cannon.getYaw() - cannon.getPrevYaw()) * partialTicks);
        poseStack.mulPose(Axis.YP.rotationDegrees(lerpYaw));

        renderCannonModel(cannon, partialTicks, resourceLocation, poseStack, multiBufferSource, packedLight);

        poseStack.popPose();

        // right click aim mode: white trajectory line along the barrel
        // (drawn OUTSIDE the scaled/rotated model pose, world aligned at the entity origin)
        if (entity.isAiming()) {
            float yaw = Mth.rotLerp(partialTicks, entity.yRotO, entity.getYRot());
            float pitch = Mth.lerp(partialTicks, entity.xRotO, entity.getXRot());
            Vec3 direction = Vec3.directionFromRotation(pitch, yaw);

            // barrel end relative to the entity origin
            Vec3 start = direction.scale(1.4D).add(0.0D, 1.1D, 0.0D);

            // match the real shot: grape/chained shot fly slower, fine grain
            // powder makes them faster (peek only, the preview must not consume it)
            float previewSpeed = CannonTrajectory.CANNON_SPEED * entity.getShotSpeedMultiplier(true);
            // the line fades out towards its far end instead of being cut at the
            // water surface, so no fluid lookup is needed here
            poseStack.pushPose();
            VertexConsumer lineConsumer = multiBufferSource.getBuffer(RenderType.lines());
            CannonTrajectory.render(poseStack, lineConsumer, CannonTrajectory.calculate(start, direction, previewSpeed));
            poseStack.popPose();
        }

        super.render(entity, entityYaw, partialTicks, poseStack, multiBufferSource, packedLight);
    }

    private final CannonModel model = new CannonModel();
    public void renderCannonModel(Cannon cannon, float partialTicks, ResourceLocation texture, @NotNull PoseStack poseStack, @NotNull MultiBufferSource multiBufferSource, int packedLight) {
        poseStack.pushPose();
        /* facing positive Z */
        poseStack.mulPose(Axis.YN.rotationDegrees(180));
        poseStack.scale(0.6F, 0.6F, 0.6F);

        /* I have no idea why the model is offset, maybe the model itself is incorrect */
        poseStack.translate(0, -1.5, 0);

        float pitch = cannon.getPrevPitch() + partialTicks * (cannon.getPitch() - cannon.getPrevPitch());
        model.setLaufPitch(pitch);

        VertexConsumer vertexConsumer = multiBufferSource.getBuffer(RenderType.entitySolid(texture));
        model.renderToBuffer(poseStack, vertexConsumer, packedLight, OverlayTexture.NO_OVERLAY);

        poseStack.popPose();
    }
}