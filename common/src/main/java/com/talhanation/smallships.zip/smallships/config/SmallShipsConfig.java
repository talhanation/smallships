package com.talhanation.smallships.config;

import com.electronwill.nightconfig.core.CommentedConfig;
import com.talhanation.smallships.SmallShipsMod;
import com.talhanation.smallships.world.entity.ship.Ship;
import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.fml.config.IConfigSpec;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class SmallShipsConfig {
    public static final ForgeConfigSpec COMMON_SPEC;
    public static final ForgeConfigSpec CLIENT_SPEC;

    public static int CLIENT_SCHEMATIC_VERSION = 3;
    public static int COMMON_SCHEMATIC_VERSION = 6;

    static {
        ForgeConfigSpec.Builder commonConfigBuilder = new ForgeConfigSpec.Builder();
        ForgeConfigSpec.Builder clientConfigBuilder = new ForgeConfigSpec.Builder();
        setupCommonConfig(commonConfigBuilder);
        setupClientConfig(clientConfigBuilder);
        COMMON_SPEC = commonConfigBuilder.build();
        CLIENT_SPEC = clientConfigBuilder.build();
    }

    @ExpectPlatform
    public static void registerConfigs(String modId, ModConfigWrapper.Type type, IConfigSpec<?> spec) {
        throw new AssertionError();
    }

    public static class Common {
        public static ForgeConfigSpec.ConfigValue<Integer> schematicVersion;

        public static ForgeConfigSpec.IntValue shipGeneralSailCooldown;
        public static ForgeConfigSpec.DoubleValue shipGeneralCollisionDamage;
        public static ForgeConfigSpec.BooleanValue shipGeneralCollisionKnockBack;
        public static ForgeConfigSpec.BooleanValue shipGeneralDoItemDrop;
        public static ForgeConfigSpec.DoubleValue shipGeneralContainerModifier;
        public static ForgeConfigSpec.DoubleValue shipGeneralCannonModifier;
        public static ForgeConfigSpec.DoubleValue shipGeneralPaddlingModifier;
        public static ForgeConfigSpec.DoubleValue shipGeneralBiomeModifier;
        public static ForgeConfigSpec.ConfigValue<List<String>> mountBlackList;
        public static ForgeConfigSpec.ConfigValue<List<String>> dockyardBuildableShips;
        public static ForgeConfigSpec.DoubleValue shipGeneralShieldDamageReduction;
        public static ForgeConfigSpec.DoubleValue shipGeneralDespawnTimeSunken;
        public static ForgeConfigSpec.DoubleValue shipGeneralCannonDamage;
        public static ForgeConfigSpec.DoubleValue shipGeneralCannonDestruction;

        // Wind (Feature: Wind)
        public static ForgeConfigSpec.BooleanValue windEnable;
        public static ForgeConfigSpec.DoubleValue windMaxSpeedInfluence;
        public static ForgeConfigSpec.ConfigValue<Integer> windChangeIntervalMin;
        public static ForgeConfigSpec.ConfigValue<Integer> windChangeIntervalMax;
        public static ForgeConfigSpec.ConfigValue<Integer> windTransitionTime;
        public static ForgeConfigSpec.DoubleValue windRainMinStrength;
        public static ForgeConfigSpec.DoubleValue windStormMinStrength;

        // Sail damage (Feature: More Cannon Balls / Chained Shot)
        public static ForgeConfigSpec.BooleanValue sailDamageEnable;
        public static ForgeConfigSpec.DoubleValue sailDamageBaseTransfer;
        public static ForgeConfigSpec.DoubleValue sailDamageChainedTransfer;
        public static ForgeConfigSpec.ConfigValue<Integer> sailRepairWoolAmount;
        public static ForgeConfigSpec.BooleanValue shipGeneralCameraFreeLook;
        public static ForgeConfigSpec.BooleanValue vanillaBoatSlowdownEnable;
        public static ForgeConfigSpec.DoubleValue vanillaBoatSpeedFactor;

        //////////////////////////////////////COG///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeCogMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeCogMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeCogMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeCogMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeCogAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeCogRotationAcceleration;
        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerCogContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierCogBiome;

        //////////////////////////////////////BRIGG///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeBriggMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeBriggMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeBriggMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeBriggMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeBriggAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeBriggRotationAcceleration;
        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerBriggContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierBriggBiome;

        //////////////////////////////////////GALLEY///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleyMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleyMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleyMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleyMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleyAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleyRotationAcceleration;
        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerGalleyContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierGalleyBiome;

        //////////////////////////////////////DRAKKAR///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeDrakkarMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeDrakkarMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeDrakkarMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeDrakkarMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeDrakkarAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeDrakkarRotationAcceleration;

        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerDrakkarContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierDrakkarBiome;
        //////////////////////////////////////DHOW///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeDhowMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeDhowMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeDhowMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeDhowMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeDhowAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeDhowRotationAcceleration;
        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerDhowContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierDhowBiome;

        //////////////////////////////////////GALLEON///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleonMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleonMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleonMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleonMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleonAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeGalleonRotationAcceleration;
        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerGalleonContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierGalleonBiome;

        //////////////////////////////////////CARAVEL///////////////////////////////////////////
        public static ForgeConfigSpec.DoubleValue shipAttributeCaravelMaxHealth;
        public static ForgeConfigSpec.DoubleValue shipAttributeCaravelMaxSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeCaravelMaxReverseSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeCaravelMaxRotationSpeed;
        public static ForgeConfigSpec.DoubleValue shipAttributeCaravelAcceleration;
        public static ForgeConfigSpec.DoubleValue shipAttributeCaravelRotationAcceleration;
        public static ForgeConfigSpec.ConfigValue<Integer> shipContainerCaravelContainerSize;
        public static ForgeConfigSpec.EnumValue<Ship.BiomeModifierType> shipModifierCaravelBiome;

        public static ForgeConfigSpec.DoubleValue waterAnimalFleeRadius;
        public static ForgeConfigSpec.DoubleValue waterAnimalFleeSpeed;
        public static ForgeConfigSpec.DoubleValue waterAnimalFleeDistance;
        public static ForgeConfigSpec.BooleanValue smallshipsItemGroupEnable;
    }

    public static class Client {
        public static ForgeConfigSpec.ConfigValue<Integer> schematicVersion;

        public static ForgeConfigSpec.BooleanValue shipGeneralCameraZoomEnable;
        public static ForgeConfigSpec.BooleanValue shipGeneralCameraAutoThirdPerson;
        public static ForgeConfigSpec.DoubleValue shipGeneralCameraZoomMax;
        public static ForgeConfigSpec.DoubleValue shipGeneralCameraZoomMin;
        public static ForgeConfigSpec.BooleanValue shipGeneralCameraShipCenterEnable;
        public static ForgeConfigSpec.BooleanValue windParticlesEnable;
        public static ForgeConfigSpec.ConfigValue<Integer> windParticlesAmount;
        public static ForgeConfigSpec.BooleanValue windBannerEnable;
        public static ForgeConfigSpec.ConfigValue<Integer> shipModSpeedUnit;
    }


    private static void setupCommonConfig(ForgeConfigSpec.Builder builder) {
        ArrayList<String> MOUNT_BLACKLIST = new ArrayList<>(
                Arrays.asList("minecraft:ender_dragon", "minecraft:wither", "minecraft:wither", "minecraft:ghast", "minecraft:warden", "minecraft:ravager", "alexmobs:cachalot_whale"));
        ArrayList<String> DOCKYARD_BUILDABLE_SHIPS = new ArrayList<>();

        builder.comment(" This holds the schematic version for internal purposes. DO NOT TOUCH!");
        Common.schematicVersion = builder.define("schematicVersion", COMMON_SCHEMATIC_VERSION);

        builder.comment(" This category holds configs that define uuid behaviour.");
        builder.push("Ship");

        builder.comment("This category holds configs that define general uuid behaviour.");
        builder.push("General");

        builder.comment("The cool-down for sails when increasing or decreasing sail state.");
        Common.shipGeneralSailCooldown = builder
                .defineInRange("shipGeneralSailCooldown", 30, 0, 1000);

        builder.comment("The damage that is delivered to entities on collision with a cruising uuid. Set 0 to disable feature.");
        Common.shipGeneralCollisionDamage = builder
                .defineInRange("shipGeneralCollisionDamage", 7.5D, 0.0D, 100.0D);

        builder.comment("Should entities be pushed on collision with a cruising uuid?");
        Common.shipGeneralCollisionKnockBack = builder
                .define("shipGeneralCollisionKnockBack", true);

        builder.comment("Should the uuid item be dropped when the uuid is fully damaged?");
        Common.shipGeneralDoItemDrop = builder
                .define("shipGeneralDoItemDrop", true);

        builder.comment("General speed modifiers for ships.");
        builder.push("Modifier");

        builder.comment("Maximum speed penalty for a filled container in percent.");
        Common.shipGeneralContainerModifier = builder
                .defineInRange("shipGeneralContainerModifier", 10.0D, -500.0D, 500.0D);

        builder.comment("Speed penalty per cannon in percent.");
        Common.shipGeneralCannonModifier = builder
                .defineInRange("shipGeneralCannonModifier", 2.5D, -500.0D, 500.0D);

        builder.comment("Speed bonus for a paddle uuid while paddling in percent.");
        Common.shipGeneralPaddlingModifier = builder
                .defineInRange("shipGeneralPaddlingModifier", 35.0D, -500.0D, 500.0D);

        builder.comment("Maximum speed bonus and penalty depending on the uuid biome type in percent.");
        Common.shipGeneralBiomeModifier = builder
                .defineInRange("shipGeneralBiomeModifier", 20.0D, 0.0D, 500.0D);

        builder.comment("Damage reduction per shield in percent.");
        Common.shipGeneralShieldDamageReduction = builder
                .defineInRange("shipGeneralShieldDamageReduction", 3.0D, -500.0D, 500.0D);

        builder.comment("Time in minutes in which sunken ships will despawn.");
        Common.shipGeneralDespawnTimeSunken = builder
                .defineInRange("shipGeneralDespawnTimeSunken", 15.0D, 0.0D, 600.0D);

        builder.comment("Entities in this list won't be able to mount a uuid, for example: [\"minecraft:creeper\", \"minecraft:sheep\", ...]");
        Common.mountBlackList = builder
                .define("mountBlackList", MOUNT_BLACKLIST);

        builder.comment("Ships that can be built at the dockyard, for example: [\"smallships:cog\", \"smallships:galley\", \"myaddon:longship\"]. An EMPTY list allows every registered ship, so ships added by addons are accepted without touching this config.");
        Common.dockyardBuildableShips = builder
                .define("dockyardBuildableShips", DOCKYARD_BUILDABLE_SHIPS);

        builder.comment("Amount of damage a cannonball does on hit.");
        Common.shipGeneralCannonDamage = builder
                .defineInRange("shipGeneralCannonDamage", 25.0D, 0.0D, 100.0D);

        builder.comment("Amount of destruction a cannonball does when hit the ground.");
        Common.shipGeneralCannonDestruction = builder
                .defineInRange("shipGeneralCannonDestruction", 1.0D, 0.0D, 100.0D);

        builder.pop();

        builder.comment("This category holds configs that define behaviour of fleeing water animals.");
        builder.push("Fleeing Water Animals");

        Common.waterAnimalFleeRadius = builder
                .defineInRange("waterAnimalFleeRadius", 15.0D, 0.0D, 100.0D);
        Common.waterAnimalFleeSpeed = builder
                .defineInRange("waterAnimalFleeSpeed", 1.5D, 0.0D, 100.0D);
        Common.waterAnimalFleeDistance = builder
                .defineInRange("waterAnimalFleeDistance", 10.0D, 0.0D, 100.0D);

        builder.pop();

        builder.pop();

        //////////////////////////////////////COG///////////////////////////////////////////
        builder.push("Cog");

        builder.comment("Default attributes for the Cog. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeCogMaxHealth = builder
                .defineInRange("shipAttributeCogMaxHealth", 300.0D, 1.0D, 10000.0D);
        Common.shipAttributeCogMaxSpeed = builder
                .defineInRange("shipAttributeCogMaxSpeed", 40.0D, 0.0D, 100.0D);
        Common.shipAttributeCogMaxReverseSpeed = builder
                .defineInRange("shipAttributeCogMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeCogMaxRotationSpeed = builder
                .defineInRange("shipAttributeCogMaxRotationSpeed", 4.5D, 0.0D, 100.0D);
        Common.shipAttributeCogAcceleration = builder
                .defineInRange("shipAttributeCogAcceleration", 0.015D, 0.0D, 100.0D);
        Common.shipAttributeCogRotationAcceleration = builder
                .defineInRange("shipAttributeCogRotationAcceleration", 0.7D, 0.0D, 100.0D);

        builder.pop();

        builder.comment("Default configs for the container of the Cog.");
        builder.push("Container");

        builder.comment("Set container size for the Cog (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerCogContainerSize = builder
                .define("shipContainerCogContainerSize", 108, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Cog specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Cog. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierCogBiome = builder
                .defineEnum("shipModifierCogBiome", Ship.BiomeModifierType.COLD);

        builder.pop();

        builder.pop();

        //////////////////////////////////////BRIGG///////////////////////////////////////////
        builder.push("Brigg");

        builder.comment("Default attributes for the Brigg. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeBriggMaxHealth = builder
                .defineInRange("shipAttributeBriggMaxHealth", 450.0D, 0.0D, 10000.0D);
        Common.shipAttributeBriggMaxSpeed = builder
                .defineInRange("shipAttributeBriggMaxSpeed", 35.0D, 0.0D, 100.0D);
        Common.shipAttributeBriggMaxReverseSpeed = builder
                .defineInRange("shipAttributeBriggMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeBriggMaxRotationSpeed = builder
                .defineInRange("shipAttributeBriggMaxRotationSpeed", 4.0D, 0.0D, 100.0D);
        Common.shipAttributeBriggAcceleration = builder
                .defineInRange("shipAttributeBriggAcceleration", 0.015D, 0.0D, 100.0D);
        Common.shipAttributeBriggRotationAcceleration = builder
                .defineInRange("shipAttributeBriggRotationAcceleration", 0.55D, 0.0D, 100.0D);

        builder.pop();

        builder.comment("Default configs for the container of the Brigg.");
        builder.push("Container");

        builder.comment("Set container size for the Brigg (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerBriggContainerSize = builder
                .define("shipContainerBriggContainerSize", 162, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Brigg specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Brigg. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierBriggBiome = builder
                .defineEnum("shipModifierBriggBiome", Ship.BiomeModifierType.COLD);

        builder.pop();

        builder.pop();
        //////////////////////////////////////GALLEY///////////////////////////////////////////

        builder.push("Galley");

        builder.comment("Default attributes for the Galley. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeGalleyMaxHealth = builder
                .defineInRange("shipAttributeGalleyMaxHealth", 200.0D, 0.0D, 10000.0D);
        Common.shipAttributeGalleyMaxSpeed = builder
                .defineInRange("shipAttributeGalleyMaxSpeed", 35.0D, 0.0D, 100.0D);
        Common.shipAttributeGalleyMaxReverseSpeed = builder
                .defineInRange("shipAttributeGalleyMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeGalleyMaxRotationSpeed = builder
                .defineInRange("shipAttributeGalleyMaxRotationSpeed", 5.0D, 0.0D, 100.0D);
        Common.shipAttributeGalleyAcceleration = builder
                .defineInRange("shipAttributeGalleyAcceleration", 0.015D, 0.0D, 100.0D);
        Common.shipAttributeGalleyRotationAcceleration = builder
                .defineInRange("shipAttributeGalleyRotationAcceleration", 1.00D, 0.0D, 100.0D);

        builder.pop();


        builder.comment("Default configs for the container of the Galley.");
        builder.push("Container");

        builder.comment("Set container size for the Galley (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerGalleyContainerSize = builder
                .define("shipContainerGalleyContainerSize", 54, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Galley specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Galley. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierGalleyBiome = builder
                .defineEnum("shipModifierGalleyBiome", Ship.BiomeModifierType.WARM);

        builder.pop();
        builder.pop();
        //////////////////////////////////////DRAKKAR///////////////////////////////////////////
        builder.push("Drakkar");

        builder.comment("Default attributes for the Drakkar. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeDrakkarMaxHealth = builder
                .defineInRange("shipAttributeDrakkarMaxHealth", 200.0D, 0.0D, 10000.0D);
        Common.shipAttributeDrakkarMaxSpeed = builder
                .defineInRange("shipAttributeDrakkarMaxSpeed", 30.0D, 0.0D, 100.0D);
        Common.shipAttributeDrakkarMaxReverseSpeed = builder
                .defineInRange("shipAttributeDrakkarMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeDrakkarMaxRotationSpeed = builder
                .defineInRange("shipAttributeDrakkarMaxRotationSpeed", 5.0D, 0.0D, 100.0D);
        Common.shipAttributeDrakkarAcceleration = builder
                .defineInRange("shipAttributeDrakkarAcceleration", 0.015D, 0.0D, 100.0D);
        Common.shipAttributeDrakkarRotationAcceleration = builder
                .defineInRange("shipAttributeDrakkarRotationAcceleration", 1.00D, 0.0D, 100.0D);

        builder.pop();

        builder.comment("Default configs for the container of the Drakkar.");
        builder.push("Container");

        builder.comment("Set container size for the Drakkar (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerDrakkarContainerSize = builder
                .define("shipContainerDrakkarContainerSize", 54, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Drakkar specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Drakkar. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierDrakkarBiome = builder
                .defineEnum("shipModifierDrakkarBiome", Ship.BiomeModifierType.COLD);

        builder.pop();
        builder.pop();

        //////////////////////////////////////GALLEON///////////////////////////////////////////

        builder.push("Galleon");

        builder.comment("Default attributes for the Galleon. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeGalleonMaxHealth = builder
                .defineInRange("shipAttributeGalleonMaxHealth", 700.0D, 0.0D, 10000.0D);
        Common.shipAttributeGalleonMaxSpeed = builder
                .defineInRange("shipAttributeGalleonMaxSpeed", 30.0D, 0.0D, 100.0D);
        Common.shipAttributeGalleonMaxReverseSpeed = builder
                .defineInRange("shipAttributeGalleonMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeGalleonMaxRotationSpeed = builder
                .defineInRange("shipAttributeGalleonMaxRotationSpeed", 3.3D, 0.0D, 100.0D);
        Common.shipAttributeGalleonAcceleration = builder
                .defineInRange("shipAttributeGalleonAcceleration", 0.013D, 0.0D, 100.0D);
        Common.shipAttributeGalleonRotationAcceleration = builder
                .defineInRange("shipAttributeGalleonRotationAcceleration", 1.00D, 0.0D, 100.0D);

        builder.pop();


        builder.comment("Default configs for the container of the Galleon.");
        builder.push("Container");

        builder.comment("Set container size for the Galleon (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerGalleonContainerSize = builder
                .define("shipContainerGalleyContainerSize", 216, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Galleon specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Galleon. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierGalleonBiome = builder
                .defineEnum("shipModifierGalleonBiome", Ship.BiomeModifierType.NEUTRAL);

        builder.pop();
        builder.pop();

        //////////////////////////////////////DHOW///////////////////////////////////////////

        builder.push("Dhow");

        builder.comment("Default attributes for the Dhow. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeDhowMaxHealth = builder
                .defineInRange("shipAttributeDhowMaxHealth", 200.0D, 0.0D, 10000.0D);
        Common.shipAttributeDhowMaxSpeed = builder
                .defineInRange("shipAttributeDhowMaxSpeed", 45.0D, 0.0D, 100.0D);
        Common.shipAttributeDhowMaxReverseSpeed = builder
                .defineInRange("shipAttributeDhowMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeDhowMaxRotationSpeed = builder
                .defineInRange("shipAttributeDhowMaxRotationSpeed", 4.5D, 0.0D, 100.0D);
        Common.shipAttributeDhowAcceleration = builder
                .defineInRange("shipAttributeDhowAcceleration", 0.015D, 0.0D, 100.0D);
        Common.shipAttributeDhowRotationAcceleration = builder
                .defineInRange("shipAttributeDhowRotationAcceleration", 1.00D, 0.0D, 100.0D);

        builder.pop();


        builder.comment("Default configs for the container of the Dhow.");
        builder.push("Container");

        builder.comment("Set container size for the Galleon (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerDhowContainerSize = builder
                .define("shipContainerDhowContainerSize", 135, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Dhow specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Dhow. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierDhowBiome = builder
                .defineEnum("shipModifierDhowBiome", Ship.BiomeModifierType.WARM);

        builder.pop();
        builder.pop();

        //////////////////////////////////////CARAVEL///////////////////////////////////////////

        builder.push("Caravel");

        builder.comment("Default attributes for the Caravel. Speed in km/h, Health in default mc health points");
        builder.push("Attributes");

        Common.shipAttributeCaravelMaxHealth = builder
                .defineInRange("shipAttributeCaravelMaxHealth", 250.0D, 0.0D, 10000.0D);
        Common.shipAttributeCaravelMaxSpeed = builder
                .defineInRange("shipAttributeCaravelMaxSpeed", 42.0D, 0.0D, 100.0D);
        Common.shipAttributeCaravelMaxReverseSpeed = builder
                .defineInRange("shipAttributeCaravelMaxReverseSpeed", 0.1D, 0.0D, 100.0D);
        Common.shipAttributeCaravelMaxRotationSpeed = builder
                .defineInRange("shipAttributeCaravelMaxRotationSpeed", 4.75D, 0.0D, 100.0D);
        Common.shipAttributeCaravelAcceleration = builder
                .defineInRange("shipAttributeCaravelAcceleration", 0.015D, 0.0D, 100.0D);
        Common.shipAttributeCaravelRotationAcceleration = builder
                .defineInRange("shipAttributeCaravelRotationAcceleration", 1.00D, 0.0D, 100.0D);

        builder.pop();


        builder.comment("Default configs for the container of the Caravel.");
        builder.push("Container");

        builder.comment("Set container size for the Galleon (value must be divisible by 9 and bigger than 0).");
        Common.shipContainerCaravelContainerSize = builder
                .define("shipContainerCaravelContainerSize", 81, e -> e instanceof Integer i && i % 9 == 0 && i > 0);

        builder.pop();

        builder.comment("Caravel specific speed modifiers.");
        builder.push("Modifier");

        builder.comment("Specify biome type for the Caravel. Can be NONE, COLD, NEUTRAL, or WARM");
        Common.shipModifierCaravelBiome = builder
                .defineEnum("shipModifierCaravelBiome", Ship.BiomeModifierType.NEUTRAL);

        builder.pop();
        builder.pop();

        ////////////////////////////////////WIND//////////////////////////////////////////////////////////

        builder.comment(" This category holds configs for the global wind.");
        builder.push("Wind");

        builder.comment("Enable the wind feature. Wind changes direction and strength at random intervals and affects sailing ships.");
        Common.windEnable = builder
                .define("windEnable", true);

        builder.comment("Maximum speed influence of the wind: 0.2 = up to +20% with full tailwind and up to -20% with full headwind.");
        Common.windMaxSpeedInfluence = builder
                .defineInRange("windMaxSpeedInfluence", 0.33D, 0.0D, 1.0D);

        builder.comment("Minimum time between wind changes in seconds.");
        Common.windChangeIntervalMin = builder
                .define("windChangeIntervalMin", 120);

        builder.comment("Maximum time between wind changes in seconds.");
        Common.windChangeIntervalMax = builder
                .define("windChangeIntervalMax", 600);

        builder.comment("Time in seconds the wind takes to smoothly transition to a new direction/strength.");
        Common.windTransitionTime = builder
                .define("windTransitionTime", 45);

        builder.comment("Minimum wind strength while raining.");
        Common.windRainMinStrength = builder
                .defineInRange("windRainMinStrength", 0.4D, 0.0D, 1.0D);

        builder.comment("Minimum wind strength while thundering.");
        Common.windStormMinStrength = builder
                .defineInRange("windStormMinStrength", 0.7D, 0.0D, 1.0D);

        builder.pop();

        builder.comment(" This category holds configs for the sail damage system.");
        builder.push("SailDamage");

        builder.comment("Enable the sail damage system. Sails have 100 hitpoints; cannon hits transfer a part of their damage to the sails.");
        Common.sailDamageEnable = builder
                .define("sailDamageEnable", true);

        builder.comment("Fraction of a cannonball hit that is transferred to the sails (default 15%).");
        Common.sailDamageBaseTransfer = builder
                .defineInRange("sailDamageBaseTransfer", 0.15D, 0.0D, 1.0D);

        builder.comment("Fraction of a chained shot hit that is transferred to the sails (default 50%).");
        Common.sailDamageChainedTransfer = builder
                .defineInRange("sailDamageChainedTransfer", 0.5D, 0.0D, 1.0D);

        builder.comment("Amount of wool needed to repair the sails by hand.");
        Common.sailRepairWoolAmount = builder
                .define("sailRepairWoolAmount", 6);

        builder.pop();

        builder.comment(" This category holds configs for the ship camera behaviour that affect gameplay.");
        builder.push("Camera");

        builder.comment("Allow a full 360 degree view for ship passengers (disables the vanilla boat rotation clamp).");
        Common.shipGeneralCameraFreeLook = builder
                .define("shipGeneralCameraFreeLook", true);

        builder.pop();

        builder.comment(" This category holds configs for vanilla boats.");
        builder.push("VanillaBoats");

        builder.comment("Slow down vanilla boats (makes smallships ships more attractive).");
        Common.vanillaBoatSlowdownEnable = builder
                .define("vanillaBoatSlowdownEnable", true);

        builder.comment("Speed factor for vanilla boats: 0.5 = 50% slower.");
        Common.vanillaBoatSpeedFactor = builder
                .defineInRange("vanillaBoatSpeedFactor", 0.75D, 0.05D, 1.0D);

        builder.pop();

        builder.pop();
    }

    private static void setupClientConfig(ForgeConfigSpec.Builder builder) {
        builder.comment(" This holds the schematic version for internal purposes. DO NOT TOUCH!");
        Client.schematicVersion = builder.define("schematicVersion", CLIENT_SCHEMATIC_VERSION);

        builder.comment(" This category holds configs that define uuid behaviour.");
        builder.push("Ship");

        builder.comment("Set the speed indication: 0 = km/h, 1 = m/s, 2 = knots, 3 = mph");
        Client.shipModSpeedUnit = builder
                .define("shipModSpeedUnit", 0);

        builder.comment("This category holds configs that define general uuid behaviour.");
        builder.push("General");


        builder.comment("General camera settings for ships.");
        builder.push("Camera");

        builder.comment("Zoom camera settings for third person view in ships.");
        builder.push("Zoom");

        builder.comment("Generally enable the zooming feature.");
        Client.shipGeneralCameraZoomEnable = builder
                .define("shipGeneralCameraZoomEnable", true);

        builder.comment("Set maximum distance of zoom (value must be smaller than or equal to 50.0).");
        Client.shipGeneralCameraZoomMax = builder
                .defineInRange("shipGeneralCameraZoomMax", 20.0D, 1.0D, 50.0D);

        builder.comment("Set minimum distance of zoom (value must be bigger than or equal to 1.0).");
        Client.shipGeneralCameraZoomMin = builder
                .defineInRange("shipGeneralCameraZoomMin", 5.0D, 1.0D, 50.0D);

        builder.pop();

        builder.comment("Automatically enable third person camera when entering a uuid.");
        Client.shipGeneralCameraAutoThirdPerson = builder
                .define("shipGeneralCameraAutoThirdPerson", true);

        builder.comment("Center the third person camera on the ship instead of the player, allowing a full 360 degree orbit.");
        Client.shipGeneralCameraShipCenterEnable = builder
                .define("shipGeneralCameraShipCenterEnable", true);

        builder.pop();

        builder.pop();

        builder.pop();

        builder.comment("Visual wind settings.");
        builder.push("Wind");

        builder.comment("Show the white wind lines on the water surface.");
        Client.windParticlesEnable = builder
                .define("windParticlesEnable", true);

        builder.comment("Base amount of wind line particles spawned per tick (scaled with wind strength).");
        Client.windParticlesAmount = builder
                .define("windParticlesAmount", 3);

        builder.comment("Let the ship banner follow the wind direction.");
        Client.windBannerEnable = builder
                .define("windBannerEnable", true);

        builder.pop();

        builder.comment(" This category holds configs that define general mod settings.");
        builder.push("General");

        builder.comment("Enable smallships creative tab in the creative inventory (only takes effect after restart).");
        Common.smallshipsItemGroupEnable = builder
                .define("smallshipsItemGroupEnable", true);

        builder.pop();
    }

    public static boolean updateConfig(ModConfigWrapper config) {
        int oldSchematicVersion = getSchematicVersion(config);
        boolean hasBeenUpdated = switch (config.getType()) {
            case COMMON -> updateConfig(config, commonSchematicUpdater);
            case CLIENT -> updateConfig(config, clientSchematicUpdater);
            case SERVER -> false;
        };
        int newSchematicVersion = getSchematicVersion(config);
        if (hasBeenUpdated) SmallShipsMod.LOGGER.warn("Updated config values of {} from schematic version {} to {}!", config.getFileName(), oldSchematicVersion, newSchematicVersion);
        return hasBeenUpdated;
    }

    private static final List<Consumer<ModConfigWrapper>> commonSchematicUpdater = new ArrayList<>();
    static {
        commonSchematicUpdater.add(config -> {
            resetEntry(config, Common.shipGeneralContainerModifier);
            resetEntry(config, Common.shipGeneralPaddlingModifier);
            resetEntry(config, Common.shipAttributeBriggMaxSpeed);
            resetEntry(config, Common.shipAttributeBriggMaxRotationSpeed);
            resetEntry(config, Common.shipAttributeBriggRotationAcceleration);
            resetEntry(config, Common.shipAttributeGalleyMaxSpeed);
            resetEntry(config, Common.shipAttributeCogMaxSpeed);
            resetEntry(config, Common.shipAttributeCogMaxRotationSpeed);
            resetEntry(config, Common.shipAttributeCogRotationAcceleration);
        });
        // To make a config update add a new element like the above to the schematic Updater field (don't ever change the order!) and don't forget to increment the default schematicVersion the setup method
    }
    private static final List<Consumer<ModConfigWrapper>> clientSchematicUpdater = new ArrayList<>();
    private static boolean updateConfig(ModConfigWrapper config, List<Consumer<ModConfigWrapper>> schematicUpdater) {
        if (getSchematicVersion(config) < schematicUpdater.size() + 1) {
            for (int i = getSchematicVersion(config) - 1; i < schematicUpdater.size(); i++) {
                int j = 0;
                while (true) {
                    try {
                        String[] fileNameExtensionPair = config.getFileName().split("\\.");
                        String backupFileName = fileNameExtensionPair[0] + "-sv" + (i + 1) + (j == 0 ? "" : "-" + j) + "." + fileNameExtensionPair[1] + ".bak";
                        Files.copy(config.getFullPath(), config.getFullPath().resolveSibling(backupFileName));
                        SmallShipsMod.LOGGER.info("Backed up previous config version: {}", backupFileName);
                        break;
                    } catch (FileAlreadyExistsException ignored) {
                        j++;
                        if (j > 99) throw new RuntimeException("Delete the " + config.getFileName() + " config files!!!");
                    } catch (IOException e) {
                        throw new RuntimeException("Could not create backup of " + config.getFileName() + " during schematicVersion update process, crashing for safety! Please backup the config file if needed and remove it from the config folder. " + e);
                    }
                }
                setSchematicVersion(config, i + 2);
                schematicUpdater.get(i).accept(config);
            }
            return true;
        }
        return false;
    }

    private static int getSchematicVersion(ModConfigWrapper config) {
        return config.getConfigData().getInt("schematicVersion");
    }
    private static void setSchematicVersion(ModConfigWrapper config, int i) {
        config.getConfigData().set("schematicVersion", i);
    }

    private static <T> void resetEntry(ModConfigWrapper config, ForgeConfigSpec.ConfigValue<T> value) {
        config.getConfigData().set(value.getPath(), value.getDefault());
    }

    public static class ModConfigWrapper {
        private final Type type;
        private final Path path;
        private final String fileName;
        private final CommentedConfig configData;

        public ModConfigWrapper(String type, Path path, String fileName, CommentedConfig configData) {
            this.path = path;
            this.fileName = fileName;
            this.type = Type.valueOf(type);
            this.configData = configData;
        }

        public Path getFullPath() {
            return path;
        }

        public String getFileName() {
            return fileName;
        }

        public Type getType() {
            return type;
        }

        public CommentedConfig getConfigData() {
            return configData;
        }

        public enum Type {
            COMMON,
            CLIENT,
            SERVER
        }
    }
}