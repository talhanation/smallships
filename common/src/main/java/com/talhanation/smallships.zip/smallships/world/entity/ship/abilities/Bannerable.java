package com.talhanation.smallships.world.entity.ship.abilities;

import com.talhanation.smallships.world.entity.ship.Ship;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BannerItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShearsItem;

public interface Bannerable extends Ability {

    default void tickBannerShip() {
        if (!self().getData(Ship.BANNER).isEmpty()) {
            self().prevBannerWaveAngle = self().bannerWaveAngle;
            self().bannerWaveAngle = (float) Math.sin(this.getBannerWaveSpeed() * (float) self().tickCount) * this.getBannerWaveFactor();
        }
    }

    default void readBannerShipSaveData(CompoundTag tag) {
        if (tag.get("Banner") instanceof CompoundTag bannerCompound) self().setData(Ship.BANNER, ItemStack.parse(self().registryAccess(), bannerCompound).orElse(ItemStack.EMPTY));
        if (tag.get("SailBanner") instanceof CompoundTag sailBannerCompound) self().setData(Ship.SAIL_BANNER, ItemStack.parse(self().registryAccess(), sailBannerCompound).orElse(ItemStack.EMPTY));
    }

    default void addBannerShipSaveData(CompoundTag tag) {
        if (!self().getData(Ship.BANNER).isEmpty()) tag.put("Banner", self().getData(Ship.BANNER).save(self().registryAccess()));
        if (!self().getData(Ship.SAIL_BANNER).isEmpty()) tag.put("SailBanner", self().getData(Ship.SAIL_BANNER).save(self().registryAccess()));
    }

    /**
     * Hand interaction fits the STAFF banner only. The sail device is painted
     * canvas work and is fitted at the dockyard - see DockyardAction.Kind.
     */
    default boolean interactBanner(Player player, InteractionHand interactionHand) {
        ItemStack item = player.getItemInHand(interactionHand);
        ItemStack shipBanner = self().getData(Ship.BANNER);
        shipBanner.setCount(1);
        if (item.getItem() instanceof BannerItem) {
            if (!shipBanner.isEmpty()) self().spawnAtLocation(shipBanner, 4);
            self().setData(Ship.BANNER, item.copy());
            if (!player.isCreative()) item.shrink(1);
            self().level().playSound(player, self().getX(), self().getY() + 4 , self().getZ(), SoundEvents.WOOL_HIT, self().getSoundSource(), 15.0F, 1.0F);
            return true;
        } else if (item.getItem() instanceof ShearsItem && !shipBanner.isEmpty()) {
            self().spawnAtLocation(shipBanner,4);
            self().setData(Ship.BANNER, ItemStack.EMPTY);
            self().level().playSound(player, self().getX(), self().getY() + 4 , self().getZ(), SoundEvents.WOOL_HIT, self().getSoundSource(), 15.0F, 1.0F);
            return true;
        }
        return false;
    }

    default float getBannerWaveFactor() {
        float base = self().level().isRaining() ? 4.5F : 3.0F;
        return base * (0.5F + self().getWind().strength());
    }

    default float getBannerWaveSpeed() {
        float base = self().level().isRaining() ? 0.55F : 0.25F;
        return base * (0.5F + self().getWind().strength());
    }

    default float getBannerWaveAngle(float partialTicks) {
        return Mth.lerp(partialTicks, self().prevBannerWaveAngle, self().bannerWaveAngle);
    }

}