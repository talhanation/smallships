package com.talhanation.smallships.mixin.controlling;

import com.talhanation.smallships.config.SyncedServerConfig;
import com.talhanation.smallships.world.entity.ship.Ship;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.WaterAnimal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(Boat.class)
public abstract class BoatMixin {
    @Shadow protected abstract void controlBoat();

    /**
     * Better Ship Camera: skip the vanilla passenger rotation clamp for ships,
     * so a full 360 degree view around the ship is possible.
     */
    @Inject(method = "clampRotation", at = @At("HEAD"), cancellable = true)
    private void smallships$skipRotationClampForShips(Entity entity, CallbackInfo ci) {
        if (((Boat)(Object)this) instanceof Ship && SyncedServerConfig.cameraFreeLook()) {
            ci.cancel();
        }
    }


    @SuppressWarnings("ConstantValue")
    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/vehicle/Boat;tickLerp()V"))
    private void tickClientAndServerControlBoat(CallbackInfo ci) {
        if (((Boat)(Object)this instanceof Ship)) {
            this.controlBoat();
        }
    }

    @SuppressWarnings("ConstantValue")
    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/vehicle/Boat;controlBoat()V"))
    private void tickCancelControlBoatHereForShip(Boat instance) {
        if (!(((Boat)(Object)this) instanceof Ship)) {
            this.controlBoat();
        }
    }

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/vehicle/Boat;checkInsideBlocks()V"), cancellable = true)
    private void tickCheckPassengersForShip(CallbackInfo ci) {
        if ((((Boat)(Object)this) instanceof Ship ship)) {

            // the ships' own box covers only a fraction of the deck, so the
            // hull parts are searched as well - see Ship#getBoardingCandidates
            List<Entity> list = ship.getBoardingCandidates();
            if (!list.isEmpty()) {
                boolean bl = !((Boat)(Object)this).getCommandSenderWorld().isClientSide && !(((Boat)(Object)this).getControllingPassenger() instanceof Player);

                for(int j = 0; j < list.size(); ++j) {
                    Entity entity = (Entity)list.get(j);
                    if (!entity.hasPassenger(((Boat)(Object)this))) {
                        if (bl && ship.canAddPassenger(entity) && !(entity instanceof Player)) {
                            entity.startRiding(((Boat)(Object)this));
                        } else {
                            ((Boat)(Object)this).push(entity);
                        }
                    }
                }
            }
            ci.cancel();
        }
    }
}